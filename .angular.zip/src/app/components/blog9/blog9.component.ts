import { Component } from '@angular/core';

@Component({
  selector: 'app-blog9',
  standalone: true,
  imports: [],
  templateUrl: './blog9.component.html',
  styleUrl: './blog9.component.scss'
})
export class Blog9Component {

}
