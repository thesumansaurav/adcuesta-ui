import { Component } from '@angular/core';

@Component({
  selector: 'app-blog2',
  standalone: true,
  imports: [],
  templateUrl: './blog2.component.html',
  styleUrl: './blog2.component.scss'
})
export class Blog2Component {

}
