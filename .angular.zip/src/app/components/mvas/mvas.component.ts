import { Component } from '@angular/core';

@Component({
  selector: 'app-mvas',
  standalone: true,
  imports: [],
  templateUrl: './mvas.component.html',
  styleUrl: './mvas.component.scss'
})
export class MvasComponent {

}
