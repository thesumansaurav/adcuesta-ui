import { Component } from '@angular/core';

@Component({
  selector: 'app-blog-details-8',
  standalone: true,
  imports: [],
  templateUrl: './blog-details-8.component.html',
  styleUrl: './blog-details-8.component.scss'
})
export class BlogDetails8Component {

}
