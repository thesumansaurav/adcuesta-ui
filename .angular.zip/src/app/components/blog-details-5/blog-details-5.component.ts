import { Component } from '@angular/core';

@Component({
  selector: 'app-blog-details-5',
  standalone: true,
  imports: [],
  templateUrl: './blog-details-5.component.html',
  styleUrl: './blog-details-5.component.scss'
})
export class BlogDetails5Component {

}
