import { Component } from '@angular/core';

@Component({
  selector: 'app-blog8',
  standalone: true,
  imports: [],
  templateUrl: './blog8.component.html',
  styleUrl: './blog8.component.scss'
})
export class Blog8Component {

}
