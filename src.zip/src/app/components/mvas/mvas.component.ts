import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-mvas',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './mvas.component.html',
  styleUrl: './mvas.component.scss'
})
export class MvasComponent {

}
