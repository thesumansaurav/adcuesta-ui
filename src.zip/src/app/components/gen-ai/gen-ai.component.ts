import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
  selector: 'app-gen-ai',
  standalone: true,
  imports: [],
  templateUrl: './gen-ai.component.html',
  styleUrl: './gen-ai.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class GenAiComponent {

}
