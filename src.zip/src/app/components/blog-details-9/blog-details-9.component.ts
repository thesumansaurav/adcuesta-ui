import { Component } from '@angular/core';

@Component({
  selector: 'app-blog-details-9',
  standalone: true,
  imports: [],
  templateUrl: './blog-details-9.component.html',
  styleUrl: './blog-details-9.component.scss'
})
export class BlogDetails9Component {

}
