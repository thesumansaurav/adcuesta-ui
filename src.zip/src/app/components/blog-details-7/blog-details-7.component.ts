import { Component } from '@angular/core';

@Component({
  selector: 'app-blog-details-7',
  standalone: true,
  imports: [],
  templateUrl: './blog-details-7.component.html',
  styleUrl: './blog-details-7.component.scss'
})
export class BlogDetails7Component {

}
