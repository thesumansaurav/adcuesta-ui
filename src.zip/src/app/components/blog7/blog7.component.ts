import { Component } from '@angular/core';

@Component({
  selector: 'app-blog7',
  standalone: true,
  imports: [],
  templateUrl: './blog7.component.html',
  styleUrl: './blog7.component.scss'
})
export class Blog7Component {

}
