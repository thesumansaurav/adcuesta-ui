import { Component } from '@angular/core';

@Component({
  selector: 'app-blog-details-6',
  standalone: true,
  imports: [],
  templateUrl: './blog-details-6.component.html',
  styleUrl: './blog-details-6.component.scss'
})
export class BlogDetails6Component {

}
