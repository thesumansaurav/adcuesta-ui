import { Component } from '@angular/core';

@Component({
  selector: 'app-header2',
  standalone: true,
  imports: [],
  templateUrl: './header2.component.html',
  styleUrl: './header2.component.scss'
})
export class Header2Component {

}
