import { Component } from '@angular/core';

@Component({
  selector: 'app-blog-details-3',
  standalone: true,
  imports: [],
  templateUrl: './blog-details-3.component.html',
  styleUrl: './blog-details-3.component.scss'
})
export class BlogDetails3Component {

}
